## How to Use

1. Create your working environment.
2. Install requirements (`$ pip install -r requirements.txt`)
3. `python manage.py migrate`
4. `python manage.py runserver`

